package com.amazon.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

public interface AmazonUserDAO {

	public boolean validateUser(String username,String password)
			throws SQLException,IOException,FileNotFoundException;
}
