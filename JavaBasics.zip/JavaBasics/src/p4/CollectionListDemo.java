package p4;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import p2.Animal;
import p2.Dog;
import p2.Tiger;

public class CollectionListDemo {

	public static void main(String[] args) {
		
		// database
		
		List<Animal> list1 = new ArrayList<>();
		
		list1.add(new Dog());
		list1.add(new Dog());
		list1.add(new Dog());
		list1.add(new Dog());
		list1.add(new Tiger());
		
		
		for (Animal animal : list1) {
			if(animal instanceof Dog)
			{
				// do dog work
				Dog d = (Dog)animal; // upcasting
				d.doPlayGames();
			}
			if(animal instanceof Tiger)
			{
				// do tiger work
			}
			
		}
		
		
		Iterator<Animal> itr = list1.iterator();
		
		while(itr.hasNext())
		{
			Animal a = itr.next();
			if(a instanceof Dog)
			{
				// do dog work
				Dog d = (Dog)a; // upcasting
				d.doPlayGames();
			}
			if(a instanceof Tiger)
			{
				// do tiger work
			}
		}
		
		
	}
}
