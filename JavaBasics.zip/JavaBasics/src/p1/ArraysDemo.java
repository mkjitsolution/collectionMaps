package p1;

import java.util.Iterator;

public class ArraysDemo {

	int x = 0;
	public static void main(String[] args) {
	
		
		int x[][] = new int[3][];
		
		x[0] = new int[2];
		x[1] = new int[4];
		x[2] = new int[3];
		
		
		x[0][1] = 101;
		x[1][3] = 333;
		
		for(int a[]:x)
		{
			for(int b:a)
			{
				System.out.print(b+" ,");
			}
			System.out.print("\n");
		}
		
		
		
		
	}//end main
	
}//end class
