package p3;

public class ExceptionHandlingDemo {

	public static void main(String[] args) {

		int arr[] = new int[3]; // 3000000

		System.out.println("A");
		try {
			System.out.println(20 / arr[2]);

		} 
		catch (ArithmeticException ae) {
			System.out.println(ae);
		} 
		catch (ArrayIndexOutOfBoundsException arrayExp) {
			System.out.println(arrayExp);
		}
		
		catch (Exception e) {
			System.out.println(e);
			System.out.println(" out of range exception.... contact to support team");
		} 
		
		System.out.println("B");

	}// end main

}// end class
