package p3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import p2.ABCExcption;
import p2.Tiger;

public class ExceptionHandlingDemo2 {

	public static void main(String[] args) {

		Tiger t = new Tiger();
		
		try {
			t.xyzWork();
			
			// 10000 
			ABCExcption abc = new ABCExcption();
			throw abc;
			
		} catch (ABCExcption e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}// end main

}// end class
