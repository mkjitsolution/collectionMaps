package p2;

public class Animal {
	
	public void doWalk(){
		// 1000 code 
		System.out.print("\n Animal - doWalk");
	   }
}
