package p2;

public class InheritanceDemo {

	public static void main(String[] args) {
		
		InheritanceDemo app = new InheritanceDemo();
		
		
		// Animal a = new Dog() // downcasting
		app.startGameApp(new Dog());
		
		
		app.startGameApp(new Tiger());
		
		/*
		 * Dog d = new Dog(); d.doWalk(); d.doPlayGames();
		 */
	
	}//end main
	
	public void startGameApp(Animal a)
	{
		
		a.doWalk();
		
		if(a instanceof Dog)
		{
			Dog d = (Dog)a; // upcasting
			d.doPlayGames();
		}
		if(a instanceof Tiger)
		{
			Tiger t = (Tiger)a;
		//	t.xyzWork();
		}
		
		
		
		
	}
		
}//end class
