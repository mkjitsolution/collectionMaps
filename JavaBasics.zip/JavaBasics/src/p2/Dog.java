package p2;
      // JAVA (SJSAS)     // TOMCAT , JBOSS, WEBLOGIC, WEB SPARE
public class Dog extends Animal {
		         
		int food = 0;
		public void doWalk(){
			food = 100;
		   System.out.print("\nDog - doWalk "+food);
		   
	    }
	           
		public void doPlayGames(){
		   System.out.print("\nDog - do play games"+food);
	   }
	
}
