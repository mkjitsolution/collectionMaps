package p2;

public class Tiger extends Animal {

	public void xyzWork() throws ABCExcption{
		// TODO Auto-generated method stub
		
	}

	
  // 1000 code
	
	
}
