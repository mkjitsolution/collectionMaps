package p2;

public class ABCExcption extends Exception {

}
