package p5;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MapDemo {

	public static void main(String[] args) {
		//Map<String, Integer> map = new HashMap();
		
		Map<String, Project> map = new HashMap<String, Project>();
		
		map.put("ramesh",new Project("Pro-123"));
		map.put("suresh",new Project("Pro-78783"));
		map.put("rakesh",new Project("Pro-1230"));
		map.put("ramesh",new Project("Pro-14523"));
		
		Project p = map.get("ramesh");
		System.out.println(p.getProjectName());

		Iterator<String> itr = map.keySet().iterator();
		while(itr.hasNext())
		{
			String keyName = itr.next();
			Project project = map.get(keyName);
			
			project.notify(); // some business method
		}
		
		
		
		
		
		
		Map<Integer,List<Project>> map2 = new HashMap<Integer, List<Project>>();
		
		
		List<Project> list1 = new LinkedList<Project>();
		list1.add(new Project("p1"));
		list1.add(new Project("p2"));
		list1.add(new Project("p3"));
		
		List<Project> list2 = new LinkedList<Project>();
		list2.add(new Project("p101"));
		list2.add(new Project("p202"));
		list2.add(new Project("p3023"));
		list2.add(new Project("p305423"));
		list2.add(new Project("p3343023"));
		
		
		List<Project> list3 = new LinkedList<Project>();
		list3.add(new Project("pA"));
		list3.add(new Project("pB"));
		list3.add(new Project("pC"));
		
		
		map2.put(1, list1);
		map2.put(2, list2);
		map2.put(3, list3);
		
		
		
		
	}

}









