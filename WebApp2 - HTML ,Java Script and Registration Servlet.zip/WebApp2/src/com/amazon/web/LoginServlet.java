package com.amazon.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amazon.dao.AmazonUserDAO;
import com.amazon.dao.AmazonUserDAOImpl;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	
    
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.print("hello secure resource");
		
	}




	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		// get data from HTML 
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		// call DAO method 
		
		try {
			AmazonUserDAO obj = new AmazonUserDAOImpl();
				
			boolean validUser = obj.validateUser(username, password);
			// process true or false
			if(validUser)
			{
				// navigation
				out.print("Welcome "+username);
				
			}
			else
			{
				// navigation
				response.sendRedirect("LoginPage.html");
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
		
		
		
		
		
		
	}//end doPost

}//end servlet
