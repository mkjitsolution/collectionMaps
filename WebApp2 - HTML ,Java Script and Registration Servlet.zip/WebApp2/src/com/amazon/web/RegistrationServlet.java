package com.amazon.web;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amazon.dao.AmazonUserDAO;
import com.amazon.dao.AmazonUserDAOImpl;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String firstname = request.getParameter("firstname");
		String loginId = request.getParameter("loginId");
		String password = request.getParameter("password");
		String confirmPassword = request.getParameter("confirmPassword");
		String state = request.getParameter("state");
		String choices[] = request.getParameterValues("choice");  
		String gender = request.getParameter("gender");
		String dateOfBirth = request.getParameter("dateOfBirth");
		
		
	
		for (String choice : choices) {
			System.out.println(choice);
		}
		
		
		try {
			
			// DAO obj 
			AmazonUserDAO dao = new AmazonUserDAOImpl();
			
			// method call
			
			boolean isInserted = dao.addUser(loginId, password);
			// validate return statement 
			
			if(isInserted)
			{
				// move to login page 
				response.sendRedirect("LoginPage.html");
			}
			else
			{
				throw new Exception("Registration Servlet Error . Pls. Try Again!!!");
			}
			
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		
		
		
		
		
	}//end doGet
}//end servlet
