package com.amazon.dao;

public class MainClassDummmy {

	public static void main(String[] args) throws Exception{
		
		AmazonUserDAOImpl obj = new AmazonUserDAOImpl();
		System.out.println(obj.addUser("rameshji", "a"));
		
	}
}
