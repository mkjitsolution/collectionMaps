package com.amazon.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class AmazonUserDAOImpl implements AmazonUserDAO {

	Connection con;
	PreparedStatement ps;

	public AmazonUserDAOImpl() throws SQLException, ClassNotFoundException {
		con = DatabaseConnectionFactory.getConnection();
	}
	
	
	
		@Override
	public boolean addUser(String username, String password) throws SQLException, IOException, FileNotFoundException {
		
			String q = "insert into amazonuser values(?,?)";
			
			ps = con.prepareStatement(q);
			ps.setString(1, username);
			ps.setString(2, password);
			
			int x = ps.executeUpdate();
			
			if(x==1) return true;
			else return false;
	}



	@Override
	public boolean validateUser(String username, String password)
			throws SQLException, IOException, FileNotFoundException {
		String q = "select * from amazonuser where username = ? and password = ?";

		ps = con.prepareStatement(q);
		ps.setString(1, username);
		ps.setString(2, password);

		ResultSet rs = ps.executeQuery();
		
		boolean found = false;
		
		while(rs.next())
		{
			found = true;
		}
		
		return found;

	}//end validate method

}// end dao class
