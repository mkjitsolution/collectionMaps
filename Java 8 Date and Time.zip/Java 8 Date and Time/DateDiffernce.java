/*https://www.javadevjournal.com/java/java-8-date-time-api/*/

package date14;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.time.chrono.Era;

public class DateDifference {

	public static void main(String[] args) {

		LocalDate d1 = LocalDate.now();
		LocalDate d2 = LocalDate.of(2019, 5,21);
		LocalDate d3 = LocalDate.of(2019, 8,22);

		int daysDifference = Period.between(d1, d2).getDays();
		int monthDifference = Period.between(d1, d2).getMonths();
		System.out.println(d1+" - "+d2+"  is "+daysDifference+" and "+monthDifference);

		daysDifference = Period.between(d3, d1).getDays();
		monthDifference = Period.between(d3, d1).getMonths();
		System.out.println(d3+" - "+d1+"  is "+daysDifference+" and "+monthDifference);


       d1 = LocalDate.now();
    		 d2 = d1.plusDays(-11);
    		System.out.println(d2);

         // ---------- Parsing ---------

    		System.out.println("Before : "+d1);

    		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/yyyy/MM");
    		String strDate = d1.format(format);
    		System.out.println("After : "+strDate);




	}
}
