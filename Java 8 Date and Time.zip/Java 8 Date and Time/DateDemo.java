import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class DateDemo
{

  public static void main(String[] args) {

		LocalDateTime dateAndTime = LocalDateTime.now();
		System.out.println(dateAndTime);

		LocalDate date = LocalDate.now();
		System.out.println("Todays Date "+date);

		LocalTime time = LocalTime.now();
		System.out.println("Current Time "+time);

		LocalDate someDate = LocalDate.of(2013,5, 4);
		System.out.println(someDate);
	}

}//end Class


/*
https://www.javadevjournal.com/java/java-8-date-time-api/
*/
