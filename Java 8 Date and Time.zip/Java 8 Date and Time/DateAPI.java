/* new java 8 Date API */

class DateAPI
{
public static void main(String[] args) {

   LocalDate date = LocalDate.now();

   int year = date.getYear();
   DayOfWeek dayWeek = date.getDayOfWeek();
   int dayMonth = date.getDayOfMonth();
   int monthValue = date.getMonthValue();
   Era era = date.getEra();

   System.out.println("year "+year);
   System.out.println("Day of Week  "+dayWeek);
   System.out.println("Day Month "+dayMonth);
   System.out.println("Month Value  "+monthValue);
   System.out.println("Era "+era);

   LocalTime time = LocalTime.now();
   int hr = time.getHour();
   System.out.println("Hr "+hr);


   String strtime = "03:30:15";
   LocalTime myTime = LocalTime.parse(strtime);
   System.out.println(myTime);
 }
}
